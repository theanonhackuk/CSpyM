﻿using System;

// Token: 0x02000404 RID: 1028
public class GClass1025
{
	// Token: 0x06000806 RID: 2054 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
