﻿using System;

// Token: 0x0200289B RID: 10395
public class GClass10392
{
	// Token: 0x06005134 RID: 20788 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
