﻿using System;

// Token: 0x02002803 RID: 10243
public class GClass10240
{
	// Token: 0x06005004 RID: 20484 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
