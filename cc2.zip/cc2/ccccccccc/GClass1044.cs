﻿using System;

// Token: 0x02000417 RID: 1047
public class GClass1044
{
	// Token: 0x0600082C RID: 2092 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
