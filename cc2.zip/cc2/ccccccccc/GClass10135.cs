﻿using System;

// Token: 0x0200279A RID: 10138
public class GClass10135
{
	// Token: 0x06004F32 RID: 20274 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
