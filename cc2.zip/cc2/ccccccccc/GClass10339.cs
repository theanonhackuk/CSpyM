﻿using System;

// Token: 0x02002866 RID: 10342
public class GClass10339
{
	// Token: 0x060050CA RID: 20682 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
