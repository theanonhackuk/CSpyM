﻿using System;

// Token: 0x0200274B RID: 10059
public class GClass10056
{
	// Token: 0x06004E94 RID: 20116 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
