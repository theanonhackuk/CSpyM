﻿using System;

// Token: 0x020027E7 RID: 10215
public class GClass10212
{
	// Token: 0x06004FCC RID: 20428 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
