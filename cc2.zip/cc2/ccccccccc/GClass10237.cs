﻿using System;

// Token: 0x02002800 RID: 10240
public class GClass10237
{
	// Token: 0x06004FFE RID: 20478 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
