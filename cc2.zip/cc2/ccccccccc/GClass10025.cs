﻿using System;

// Token: 0x0200272C RID: 10028
public class GClass10025
{
	// Token: 0x06004E56 RID: 20054 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
