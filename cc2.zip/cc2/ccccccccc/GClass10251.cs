﻿using System;

// Token: 0x0200280E RID: 10254
public class GClass10251
{
	// Token: 0x0600501A RID: 20506 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
