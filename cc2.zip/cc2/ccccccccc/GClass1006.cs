﻿using System;

// Token: 0x020003F1 RID: 1009
public class GClass1006
{
	// Token: 0x060007E0 RID: 2016 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
