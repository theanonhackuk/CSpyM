﻿using System;

// Token: 0x02002830 RID: 10288
public class GClass10285
{
	// Token: 0x0600505E RID: 20574 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
