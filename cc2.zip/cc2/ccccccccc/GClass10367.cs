﻿using System;

// Token: 0x02002882 RID: 10370
public class GClass10367
{
	// Token: 0x06005102 RID: 20738 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
