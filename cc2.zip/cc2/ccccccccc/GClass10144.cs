﻿using System;

// Token: 0x020027A3 RID: 10147
public class GClass10144
{
	// Token: 0x06004F44 RID: 20292 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
