﻿using System;

// Token: 0x020027E5 RID: 10213
public class GClass10210
{
	// Token: 0x06004FC8 RID: 20424 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
