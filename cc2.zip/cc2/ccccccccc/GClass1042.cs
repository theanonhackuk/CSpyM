﻿using System;

// Token: 0x02000415 RID: 1045
public class GClass1042
{
	// Token: 0x06000828 RID: 2088 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
