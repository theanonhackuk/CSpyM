﻿using System;

// Token: 0x02002844 RID: 10308
public class GClass10305
{
	// Token: 0x06005086 RID: 20614 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
