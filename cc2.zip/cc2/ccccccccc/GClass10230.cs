﻿using System;

// Token: 0x020027F9 RID: 10233
public class GClass10230
{
	// Token: 0x06004FF0 RID: 20464 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
