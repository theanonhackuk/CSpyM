﻿using System;

// Token: 0x020027D8 RID: 10200
public class GClass10197
{
	// Token: 0x06004FAE RID: 20398 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
