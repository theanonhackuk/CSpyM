﻿using System;

// Token: 0x0200279B RID: 10139
public class GClass10136
{
	// Token: 0x06004F34 RID: 20276 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
