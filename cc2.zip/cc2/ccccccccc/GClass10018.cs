﻿using System;

// Token: 0x02002725 RID: 10021
public class GClass10018
{
	// Token: 0x06004E48 RID: 20040 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
