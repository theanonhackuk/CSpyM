﻿using System;

// Token: 0x020027D5 RID: 10197
public class GClass10194
{
	// Token: 0x06004FA8 RID: 20392 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
