﻿using System;

// Token: 0x020027A9 RID: 10153
public class GClass10150
{
	// Token: 0x06004F50 RID: 20304 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
