﻿using System;

// Token: 0x020027F4 RID: 10228
public class GClass10225
{
	// Token: 0x06004FE6 RID: 20454 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
