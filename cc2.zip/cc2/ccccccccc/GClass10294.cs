﻿using System;

// Token: 0x02002839 RID: 10297
public class GClass10294
{
	// Token: 0x06005070 RID: 20592 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
