﻿using System;

// Token: 0x02002785 RID: 10117
public class GClass10114
{
	// Token: 0x06004F08 RID: 20232 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
