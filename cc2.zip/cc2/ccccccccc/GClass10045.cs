﻿using System;

// Token: 0x02002740 RID: 10048
public class GClass10045
{
	// Token: 0x06004E7E RID: 20094 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
