﻿using System;

// Token: 0x02002777 RID: 10103
public class GClass10100
{
	// Token: 0x06004EEC RID: 20204 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
