﻿using System;

// Token: 0x02002727 RID: 10023
public class GClass10020
{
	// Token: 0x06004E4C RID: 20044 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
