﻿using System;

// Token: 0x020028CC RID: 10444
public class GClass10441
{
	// Token: 0x06005196 RID: 20886 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
