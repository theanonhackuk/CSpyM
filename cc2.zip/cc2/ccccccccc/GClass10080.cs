﻿using System;

// Token: 0x02002763 RID: 10083
public class GClass10080
{
	// Token: 0x06004EC4 RID: 20164 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
