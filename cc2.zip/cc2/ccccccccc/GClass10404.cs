﻿using System;

// Token: 0x020028A7 RID: 10407
public class GClass10404
{
	// Token: 0x0600514C RID: 20812 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
