﻿using System;

// Token: 0x020027EE RID: 10222
public class GClass10219
{
	// Token: 0x06004FDA RID: 20442 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
