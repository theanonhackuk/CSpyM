﻿using System;

// Token: 0x020028AD RID: 10413
public class GClass10410
{
	// Token: 0x06005158 RID: 20824 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
