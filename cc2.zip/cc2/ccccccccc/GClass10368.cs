﻿using System;

// Token: 0x02002883 RID: 10371
public class GClass10368
{
	// Token: 0x06005104 RID: 20740 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
