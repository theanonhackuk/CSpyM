﻿using System;

// Token: 0x02002773 RID: 10099
public class GClass10096
{
	// Token: 0x06004EE4 RID: 20196 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
