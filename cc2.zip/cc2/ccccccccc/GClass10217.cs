﻿using System;

// Token: 0x020027EC RID: 10220
public class GClass10217
{
	// Token: 0x06004FD6 RID: 20438 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
