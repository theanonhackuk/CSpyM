﻿using System;

// Token: 0x020028C5 RID: 10437
public class GClass10434
{
	// Token: 0x06005188 RID: 20872 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
