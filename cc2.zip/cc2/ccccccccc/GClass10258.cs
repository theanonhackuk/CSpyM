﻿using System;

// Token: 0x02002815 RID: 10261
public class GClass10258
{
	// Token: 0x06005028 RID: 20520 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
