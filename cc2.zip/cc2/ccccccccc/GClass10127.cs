﻿using System;

// Token: 0x02002792 RID: 10130
public class GClass10127
{
	// Token: 0x06004F22 RID: 20258 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
