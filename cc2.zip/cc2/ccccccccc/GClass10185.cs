﻿using System;

// Token: 0x020027CC RID: 10188
public class GClass10185
{
	// Token: 0x06004F96 RID: 20374 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
