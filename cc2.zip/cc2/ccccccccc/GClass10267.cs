﻿using System;

// Token: 0x0200281E RID: 10270
public class GClass10267
{
	// Token: 0x0600503A RID: 20538 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
