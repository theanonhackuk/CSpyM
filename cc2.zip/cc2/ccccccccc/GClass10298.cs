﻿using System;

// Token: 0x0200283D RID: 10301
public class GClass10298
{
	// Token: 0x06005078 RID: 20600 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
