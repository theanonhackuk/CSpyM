﻿using System;

// Token: 0x0200283F RID: 10303
public class GClass10300
{
	// Token: 0x0600507C RID: 20604 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
