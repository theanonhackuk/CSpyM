﻿using System;

// Token: 0x02002863 RID: 10339
public class GClass10336
{
	// Token: 0x060050C4 RID: 20676 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
