﻿using System;

// Token: 0x02002749 RID: 10057
public class GClass10054
{
	// Token: 0x06004E90 RID: 20112 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
