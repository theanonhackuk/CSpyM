﻿using System;

// Token: 0x020027A6 RID: 10150
public class GClass10147
{
	// Token: 0x06004F4A RID: 20298 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
