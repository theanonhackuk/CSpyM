﻿using System;

// Token: 0x020028C3 RID: 10435
public class GClass10432
{
	// Token: 0x06005184 RID: 20868 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
