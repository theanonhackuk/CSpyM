﻿using System;

// Token: 0x02002809 RID: 10249
public class GClass10246
{
	// Token: 0x06005010 RID: 20496 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
