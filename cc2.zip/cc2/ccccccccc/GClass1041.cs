﻿using System;

// Token: 0x02000414 RID: 1044
public class GClass1041
{
	// Token: 0x06000826 RID: 2086 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
