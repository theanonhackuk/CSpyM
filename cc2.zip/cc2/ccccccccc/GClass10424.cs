﻿using System;

// Token: 0x020028BB RID: 10427
public class GClass10424
{
	// Token: 0x06005174 RID: 20852 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
