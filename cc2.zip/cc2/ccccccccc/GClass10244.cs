﻿using System;

// Token: 0x02002807 RID: 10247
public class GClass10244
{
	// Token: 0x0600500C RID: 20492 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
