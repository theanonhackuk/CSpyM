﻿using System;

// Token: 0x0200275C RID: 10076
public class GClass10073
{
	// Token: 0x06004EB6 RID: 20150 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
