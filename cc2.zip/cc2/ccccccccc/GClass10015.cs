﻿using System;

// Token: 0x02002722 RID: 10018
public class GClass10015
{
	// Token: 0x06004E42 RID: 20034 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
