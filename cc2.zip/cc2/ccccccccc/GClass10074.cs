﻿using System;

// Token: 0x0200275D RID: 10077
public class GClass10074
{
	// Token: 0x06004EB8 RID: 20152 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
