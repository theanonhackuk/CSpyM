﻿using System;

// Token: 0x020027EA RID: 10218
public class GClass10215
{
	// Token: 0x06004FD2 RID: 20434 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
