﻿using System;

// Token: 0x0200272E RID: 10030
public class GClass10027
{
	// Token: 0x06004E5A RID: 20058 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
