﻿using System;

// Token: 0x0200273D RID: 10045
public class GClass10042
{
	// Token: 0x06004E78 RID: 20088 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
