﻿using System;

// Token: 0x020028A2 RID: 10402
public class GClass10399
{
	// Token: 0x06005142 RID: 20802 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
