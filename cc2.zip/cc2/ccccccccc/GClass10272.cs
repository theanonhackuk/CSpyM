﻿using System;

// Token: 0x02002823 RID: 10275
public class GClass10272
{
	// Token: 0x06005044 RID: 20548 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
