﻿using System;

// Token: 0x02002787 RID: 10119
public class GClass10116
{
	// Token: 0x06004F0C RID: 20236 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
