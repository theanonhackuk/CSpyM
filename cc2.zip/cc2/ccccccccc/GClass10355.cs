﻿using System;

// Token: 0x02002876 RID: 10358
public class GClass10355
{
	// Token: 0x060050EA RID: 20714 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
