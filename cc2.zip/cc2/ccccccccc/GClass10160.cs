﻿using System;

// Token: 0x020027B3 RID: 10163
public class GClass10160
{
	// Token: 0x06004F64 RID: 20324 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
