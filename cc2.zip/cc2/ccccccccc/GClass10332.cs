﻿using System;

// Token: 0x0200285F RID: 10335
public class GClass10332
{
	// Token: 0x060050BC RID: 20668 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
