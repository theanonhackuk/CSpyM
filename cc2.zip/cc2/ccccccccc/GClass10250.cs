﻿using System;

// Token: 0x0200280D RID: 10253
public class GClass10250
{
	// Token: 0x06005018 RID: 20504 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
