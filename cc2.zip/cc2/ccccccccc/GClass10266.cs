﻿using System;

// Token: 0x0200281D RID: 10269
public class GClass10266
{
	// Token: 0x06005038 RID: 20536 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
