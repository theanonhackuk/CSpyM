﻿using System;

// Token: 0x02002783 RID: 10115
public class GClass10112
{
	// Token: 0x06004F04 RID: 20228 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
