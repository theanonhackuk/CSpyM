﻿using System;

// Token: 0x020003F2 RID: 1010
public class GClass1007
{
	// Token: 0x060007E2 RID: 2018 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
