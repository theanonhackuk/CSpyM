﻿using System;

// Token: 0x020028CB RID: 10443
public class GClass10440
{
	// Token: 0x06005194 RID: 20884 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
