﻿using System;

// Token: 0x020027CE RID: 10190
public class GClass10187
{
	// Token: 0x06004F9A RID: 20378 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
