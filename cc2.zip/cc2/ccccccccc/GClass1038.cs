﻿using System;

// Token: 0x02000411 RID: 1041
public class GClass1038
{
	// Token: 0x06000820 RID: 2080 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
