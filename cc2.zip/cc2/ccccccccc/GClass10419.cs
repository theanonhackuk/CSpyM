﻿using System;

// Token: 0x020028B6 RID: 10422
public class GClass10419
{
	// Token: 0x0600516A RID: 20842 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
