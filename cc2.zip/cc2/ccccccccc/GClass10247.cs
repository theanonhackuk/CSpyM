﻿using System;

// Token: 0x0200280A RID: 10250
public class GClass10247
{
	// Token: 0x06005012 RID: 20498 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
