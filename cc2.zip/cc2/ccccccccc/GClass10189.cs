﻿using System;

// Token: 0x020027D0 RID: 10192
public class GClass10189
{
	// Token: 0x06004F9E RID: 20382 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
