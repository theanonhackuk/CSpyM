﻿using System;

// Token: 0x02002764 RID: 10084
public class GClass10081
{
	// Token: 0x06004EC6 RID: 20166 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
