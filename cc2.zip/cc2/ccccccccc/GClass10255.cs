﻿using System;

// Token: 0x02002812 RID: 10258
public class GClass10255
{
	// Token: 0x06005022 RID: 20514 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
