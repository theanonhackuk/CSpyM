﻿using System;

// Token: 0x020003F4 RID: 1012
public class GClass1009
{
	// Token: 0x060007E6 RID: 2022 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
