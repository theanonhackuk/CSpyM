﻿using System;

// Token: 0x020028C4 RID: 10436
public class GClass10433
{
	// Token: 0x06005186 RID: 20870 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
