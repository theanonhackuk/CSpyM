﻿using System;

// Token: 0x020027FB RID: 10235
public class GClass10232
{
	// Token: 0x06004FF4 RID: 20468 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
