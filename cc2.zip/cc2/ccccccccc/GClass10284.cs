﻿using System;

// Token: 0x0200282F RID: 10287
public class GClass10284
{
	// Token: 0x0600505C RID: 20572 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
