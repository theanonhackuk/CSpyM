﻿using System;

// Token: 0x0200284B RID: 10315
public class GClass10312
{
	// Token: 0x06005094 RID: 20628 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
