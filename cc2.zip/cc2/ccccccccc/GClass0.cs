﻿using System;

// Token: 0x02000003 RID: 3
public class GClass0
{
	// Token: 0x06000004 RID: 4 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
