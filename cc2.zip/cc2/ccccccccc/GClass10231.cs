﻿using System;

// Token: 0x020027FA RID: 10234
public class GClass10231
{
	// Token: 0x06004FF2 RID: 20466 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
