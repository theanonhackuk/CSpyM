﻿using System;

// Token: 0x0200271A RID: 10010
public class GClass10007
{
	// Token: 0x06004E32 RID: 20018 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
