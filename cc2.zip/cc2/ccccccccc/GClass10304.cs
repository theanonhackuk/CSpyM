﻿using System;

// Token: 0x02002843 RID: 10307
public class GClass10304
{
	// Token: 0x06005084 RID: 20612 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
