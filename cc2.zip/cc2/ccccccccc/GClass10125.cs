﻿using System;

// Token: 0x02002790 RID: 10128
public class GClass10125
{
	// Token: 0x06004F1E RID: 20254 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
