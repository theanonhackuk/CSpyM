﻿using System;

// Token: 0x020027B7 RID: 10167
public class GClass10164
{
	// Token: 0x06004F6C RID: 20332 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
