﻿using System;

// Token: 0x0200284E RID: 10318
public class GClass10315
{
	// Token: 0x0600509A RID: 20634 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
