﻿using System;

// Token: 0x0200287E RID: 10366
public class GClass10363
{
	// Token: 0x060050FA RID: 20730 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
