﻿using System;

// Token: 0x02002898 RID: 10392
public class GClass10389
{
	// Token: 0x0600512E RID: 20782 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
