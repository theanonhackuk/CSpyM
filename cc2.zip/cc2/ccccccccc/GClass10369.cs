﻿using System;

// Token: 0x02002884 RID: 10372
public class GClass10369
{
	// Token: 0x06005106 RID: 20742 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
