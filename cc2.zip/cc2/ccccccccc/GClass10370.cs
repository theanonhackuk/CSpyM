﻿using System;

// Token: 0x02002885 RID: 10373
public class GClass10370
{
	// Token: 0x06005108 RID: 20744 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
