﻿using System;

// Token: 0x020003F5 RID: 1013
public class GClass1010
{
	// Token: 0x060007E8 RID: 2024 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
