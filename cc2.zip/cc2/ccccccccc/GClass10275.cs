﻿using System;

// Token: 0x02002826 RID: 10278
public class GClass10275
{
	// Token: 0x0600504A RID: 20554 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
