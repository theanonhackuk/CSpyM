﻿using System;

// Token: 0x020027F2 RID: 10226
public class GClass10223
{
	// Token: 0x06004FE2 RID: 20450 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
