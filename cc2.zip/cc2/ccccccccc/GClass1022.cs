﻿using System;

// Token: 0x02000401 RID: 1025
public class GClass1022
{
	// Token: 0x06000800 RID: 2048 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
