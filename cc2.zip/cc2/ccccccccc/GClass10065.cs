﻿using System;

// Token: 0x02002754 RID: 10068
public class GClass10065
{
	// Token: 0x06004EA6 RID: 20134 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
