﻿using System;

// Token: 0x02000409 RID: 1033
public class GClass1030
{
	// Token: 0x06000810 RID: 2064 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
