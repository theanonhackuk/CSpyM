﻿using System;

// Token: 0x020027EB RID: 10219
public class GClass10216
{
	// Token: 0x06004FD4 RID: 20436 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
