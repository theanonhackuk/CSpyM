﻿using System;

// Token: 0x02002848 RID: 10312
public class GClass10309
{
	// Token: 0x0600508E RID: 20622 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
