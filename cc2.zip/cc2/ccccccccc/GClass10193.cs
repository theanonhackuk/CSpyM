﻿using System;

// Token: 0x020027D4 RID: 10196
public class GClass10193
{
	// Token: 0x06004FA6 RID: 20390 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
