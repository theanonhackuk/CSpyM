﻿using System;

// Token: 0x020003ED RID: 1005
public class GClass1002
{
	// Token: 0x060007D8 RID: 2008 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
