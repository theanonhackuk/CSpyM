﻿using System;

// Token: 0x02002786 RID: 10118
public class GClass10115
{
	// Token: 0x06004F0A RID: 20234 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
