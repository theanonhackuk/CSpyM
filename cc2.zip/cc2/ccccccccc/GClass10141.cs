﻿using System;

// Token: 0x020027A0 RID: 10144
public class GClass10141
{
	// Token: 0x06004F3E RID: 20286 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
