﻿using System;

// Token: 0x02002835 RID: 10293
public class GClass10290
{
	// Token: 0x06005068 RID: 20584 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
