﻿using System;

// Token: 0x0200278A RID: 10122
public class GClass10119
{
	// Token: 0x06004F12 RID: 20242 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
