﻿using System;

// Token: 0x02002871 RID: 10353
public class GClass10350
{
	// Token: 0x060050E0 RID: 20704 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
