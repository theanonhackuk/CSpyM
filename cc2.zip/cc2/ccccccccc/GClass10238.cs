﻿using System;

// Token: 0x02002801 RID: 10241
public class GClass10238
{
	// Token: 0x06005000 RID: 20480 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
