﻿using System;

// Token: 0x02000413 RID: 1043
public class GClass1040
{
	// Token: 0x06000824 RID: 2084 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
