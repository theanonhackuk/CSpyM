﻿using System;

// Token: 0x02002849 RID: 10313
public class GClass10310
{
	// Token: 0x06005090 RID: 20624 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
