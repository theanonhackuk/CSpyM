﻿using System;

// Token: 0x020027DF RID: 10207
public class GClass10204
{
	// Token: 0x06004FBC RID: 20412 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
