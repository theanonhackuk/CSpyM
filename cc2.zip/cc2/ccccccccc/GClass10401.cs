﻿using System;

// Token: 0x020028A4 RID: 10404
public class GClass10401
{
	// Token: 0x06005146 RID: 20806 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
