﻿using System;

// Token: 0x020027C7 RID: 10183
public class GClass10180
{
	// Token: 0x06004F8C RID: 20364 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
