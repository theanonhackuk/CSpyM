﻿using System;

// Token: 0x020003FD RID: 1021
public class GClass1018
{
	// Token: 0x060007F8 RID: 2040 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
