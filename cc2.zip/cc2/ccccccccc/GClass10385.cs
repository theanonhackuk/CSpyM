﻿using System;

// Token: 0x02002894 RID: 10388
public class GClass10385
{
	// Token: 0x06005126 RID: 20774 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
