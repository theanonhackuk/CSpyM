﻿using System;

// Token: 0x02002837 RID: 10295
public class GClass10292
{
	// Token: 0x0600506C RID: 20588 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
