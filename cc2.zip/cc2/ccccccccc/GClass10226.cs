﻿using System;

// Token: 0x020027F5 RID: 10229
public class GClass10226
{
	// Token: 0x06004FE8 RID: 20456 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
