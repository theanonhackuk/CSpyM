﻿using System;

// Token: 0x0200284F RID: 10319
public class GClass10316
{
	// Token: 0x0600509C RID: 20636 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
