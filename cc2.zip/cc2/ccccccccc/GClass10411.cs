﻿using System;

// Token: 0x020028AE RID: 10414
public class GClass10411
{
	// Token: 0x0600515A RID: 20826 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
