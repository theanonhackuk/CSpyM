﻿using System;

// Token: 0x02002730 RID: 10032
public class GClass10029
{
	// Token: 0x06004E5E RID: 20062 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
