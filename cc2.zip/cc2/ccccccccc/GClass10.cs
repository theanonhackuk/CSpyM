﻿using System;

// Token: 0x0200000D RID: 13
public class GClass10
{
	// Token: 0x06000018 RID: 24 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
