﻿using System;

// Token: 0x02002811 RID: 10257
public class GClass10254
{
	// Token: 0x06005020 RID: 20512 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
