﻿using System;

// Token: 0x02000406 RID: 1030
public class GClass1027
{
	// Token: 0x0600080A RID: 2058 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
