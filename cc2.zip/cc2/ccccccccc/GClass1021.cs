﻿using System;

// Token: 0x02000400 RID: 1024
public class GClass1021
{
	// Token: 0x060007FE RID: 2046 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
