﻿using System;

// Token: 0x02002755 RID: 10069
public class GClass10066
{
	// Token: 0x06004EA8 RID: 20136 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
