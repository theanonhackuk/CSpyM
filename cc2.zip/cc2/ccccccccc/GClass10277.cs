﻿using System;

// Token: 0x02002828 RID: 10280
public class GClass10277
{
	// Token: 0x0600504E RID: 20558 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
