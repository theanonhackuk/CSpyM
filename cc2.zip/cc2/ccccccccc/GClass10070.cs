﻿using System;

// Token: 0x02002759 RID: 10073
public class GClass10070
{
	// Token: 0x06004EB0 RID: 20144 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
