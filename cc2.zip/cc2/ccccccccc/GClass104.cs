﻿using System;

// Token: 0x0200006B RID: 107
public class GClass104
{
	// Token: 0x060000D4 RID: 212 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
