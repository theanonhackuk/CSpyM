﻿using System;

// Token: 0x020028AB RID: 10411
public class GClass10408
{
	// Token: 0x06005154 RID: 20820 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
