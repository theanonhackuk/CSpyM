﻿using System;

// Token: 0x020027F0 RID: 10224
public class GClass10221
{
	// Token: 0x06004FDE RID: 20446 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
