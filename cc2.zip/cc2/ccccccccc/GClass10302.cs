﻿using System;

// Token: 0x02002841 RID: 10305
public class GClass10302
{
	// Token: 0x06005080 RID: 20608 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
