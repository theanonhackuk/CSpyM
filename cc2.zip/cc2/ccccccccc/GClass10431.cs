﻿using System;

// Token: 0x020028C2 RID: 10434
public class GClass10431
{
	// Token: 0x06005182 RID: 20866 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
