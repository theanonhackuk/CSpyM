﻿using System;

// Token: 0x0200273F RID: 10047
public class GClass10044
{
	// Token: 0x06004E7C RID: 20092 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
