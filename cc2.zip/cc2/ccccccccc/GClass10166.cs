﻿using System;

// Token: 0x020027B9 RID: 10169
public class GClass10166
{
	// Token: 0x06004F70 RID: 20336 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
