﻿using System;

// Token: 0x0200279E RID: 10142
public class GClass10139
{
	// Token: 0x06004F3A RID: 20282 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
