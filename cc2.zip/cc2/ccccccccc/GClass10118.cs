﻿using System;

// Token: 0x02002789 RID: 10121
public class GClass10118
{
	// Token: 0x06004F10 RID: 20240 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
