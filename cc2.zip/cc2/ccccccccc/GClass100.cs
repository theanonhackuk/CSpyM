﻿using System;

// Token: 0x02000067 RID: 103
public class GClass100
{
	// Token: 0x060000CC RID: 204 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
