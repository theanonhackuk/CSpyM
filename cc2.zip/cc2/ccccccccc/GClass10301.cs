﻿using System;

// Token: 0x02002840 RID: 10304
public class GClass10301
{
	// Token: 0x0600507E RID: 20606 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
