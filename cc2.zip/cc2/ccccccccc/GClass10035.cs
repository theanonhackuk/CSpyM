﻿using System;

// Token: 0x02002736 RID: 10038
public class GClass10035
{
	// Token: 0x06004E6A RID: 20074 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
