﻿using System;

// Token: 0x020027F1 RID: 10225
public class GClass10222
{
	// Token: 0x06004FE0 RID: 20448 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
