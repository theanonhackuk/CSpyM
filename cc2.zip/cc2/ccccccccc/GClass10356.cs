﻿using System;

// Token: 0x02002877 RID: 10359
public class GClass10356
{
	// Token: 0x060050EC RID: 20716 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
