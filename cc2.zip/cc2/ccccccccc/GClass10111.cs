﻿using System;

// Token: 0x02002782 RID: 10114
public class GClass10111
{
	// Token: 0x06004F02 RID: 20226 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
