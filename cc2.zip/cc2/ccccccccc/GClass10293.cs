﻿using System;

// Token: 0x02002838 RID: 10296
public class GClass10293
{
	// Token: 0x0600506E RID: 20590 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
