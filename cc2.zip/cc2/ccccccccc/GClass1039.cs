﻿using System;

// Token: 0x02000412 RID: 1042
public class GClass1039
{
	// Token: 0x06000822 RID: 2082 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
