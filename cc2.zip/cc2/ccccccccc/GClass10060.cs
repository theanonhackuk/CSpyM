﻿using System;

// Token: 0x0200274F RID: 10063
public class GClass10060
{
	// Token: 0x06004E9C RID: 20124 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
