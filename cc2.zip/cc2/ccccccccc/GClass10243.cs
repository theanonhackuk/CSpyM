﻿using System;

// Token: 0x02002806 RID: 10246
public class GClass10243
{
	// Token: 0x0600500A RID: 20490 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
