﻿using System;

// Token: 0x020027F8 RID: 10232
public class GClass10229
{
	// Token: 0x06004FEE RID: 20462 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
