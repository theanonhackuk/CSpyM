﻿using System;

// Token: 0x020028A6 RID: 10406
public class GClass10403
{
	// Token: 0x0600514A RID: 20810 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
