﻿using System;

// Token: 0x020028C0 RID: 10432
public class GClass10429
{
	// Token: 0x0600517E RID: 20862 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
