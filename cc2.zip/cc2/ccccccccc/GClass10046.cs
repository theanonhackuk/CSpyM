﻿using System;

// Token: 0x02002741 RID: 10049
public class GClass10046
{
	// Token: 0x06004E80 RID: 20096 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
