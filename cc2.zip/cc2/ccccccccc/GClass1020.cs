﻿using System;

// Token: 0x020003FF RID: 1023
public class GClass1020
{
	// Token: 0x060007FC RID: 2044 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
