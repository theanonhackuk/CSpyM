﻿using System;

// Token: 0x0200273B RID: 10043
public class GClass10040
{
	// Token: 0x06004E74 RID: 20084 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
