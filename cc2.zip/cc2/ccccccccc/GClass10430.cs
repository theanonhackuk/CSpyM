﻿using System;

// Token: 0x020028C1 RID: 10433
public class GClass10430
{
	// Token: 0x06005180 RID: 20864 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
