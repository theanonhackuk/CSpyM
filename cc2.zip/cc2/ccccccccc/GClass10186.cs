﻿using System;

// Token: 0x020027CD RID: 10189
public class GClass10186
{
	// Token: 0x06004F98 RID: 20376 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
