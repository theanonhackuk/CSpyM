﻿using System;

// Token: 0x020003FE RID: 1022
public class GClass1019
{
	// Token: 0x060007FA RID: 2042 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
