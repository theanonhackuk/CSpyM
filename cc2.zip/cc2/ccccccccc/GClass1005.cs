﻿using System;

// Token: 0x020003F0 RID: 1008
public class GClass1005
{
	// Token: 0x060007DE RID: 2014 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
