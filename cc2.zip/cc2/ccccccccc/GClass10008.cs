﻿using System;

// Token: 0x0200271B RID: 10011
public class GClass10008
{
	// Token: 0x06004E34 RID: 20020 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
