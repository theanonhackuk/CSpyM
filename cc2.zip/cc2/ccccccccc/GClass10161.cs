﻿using System;

// Token: 0x020027B4 RID: 10164
public class GClass10161
{
	// Token: 0x06004F66 RID: 20326 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
