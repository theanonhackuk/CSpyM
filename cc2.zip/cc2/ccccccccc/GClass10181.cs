﻿using System;

// Token: 0x020027C8 RID: 10184
public class GClass10181
{
	// Token: 0x06004F8E RID: 20366 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
