﻿using System;

// Token: 0x02002765 RID: 10085
public class GClass10082
{
	// Token: 0x06004EC8 RID: 20168 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
