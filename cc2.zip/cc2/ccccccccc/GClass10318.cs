﻿using System;

// Token: 0x02002851 RID: 10321
public class GClass10318
{
	// Token: 0x060050A0 RID: 20640 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
