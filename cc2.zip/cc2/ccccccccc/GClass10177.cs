﻿using System;

// Token: 0x020027C4 RID: 10180
public class GClass10177
{
	// Token: 0x06004F86 RID: 20358 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
