﻿using System;

// Token: 0x02002891 RID: 10385
public class GClass10382
{
	// Token: 0x06005120 RID: 20768 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
