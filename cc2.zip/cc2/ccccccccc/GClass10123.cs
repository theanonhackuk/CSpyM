﻿using System;

// Token: 0x0200278E RID: 10126
public class GClass10123
{
	// Token: 0x06004F1A RID: 20250 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
