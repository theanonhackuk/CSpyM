﻿using System;

// Token: 0x02002834 RID: 10292
public class GClass10289
{
	// Token: 0x06005066 RID: 20582 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
