﻿using System;

// Token: 0x020003FB RID: 1019
public class GClass1016
{
	// Token: 0x060007F4 RID: 2036 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
