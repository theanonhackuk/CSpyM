﻿using System;

// Token: 0x02002798 RID: 10136
public class GClass10133
{
	// Token: 0x06004F2E RID: 20270 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
