﻿using System;

// Token: 0x02002802 RID: 10242
public class GClass10239
{
	// Token: 0x06005002 RID: 20482 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
