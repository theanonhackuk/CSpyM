﻿using System;

// Token: 0x0200280F RID: 10255
public class GClass10252
{
	// Token: 0x0600501C RID: 20508 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
