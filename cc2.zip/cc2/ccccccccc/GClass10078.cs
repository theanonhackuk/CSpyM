﻿using System;

// Token: 0x02002761 RID: 10081
public class GClass10078
{
	// Token: 0x06004EC0 RID: 20160 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
