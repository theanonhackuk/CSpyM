﻿using System;

// Token: 0x0200283B RID: 10299
public class GClass10296
{
	// Token: 0x06005074 RID: 20596 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
