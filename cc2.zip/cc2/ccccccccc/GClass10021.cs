﻿using System;

// Token: 0x02002728 RID: 10024
public class GClass10021
{
	// Token: 0x06004E4E RID: 20046 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
