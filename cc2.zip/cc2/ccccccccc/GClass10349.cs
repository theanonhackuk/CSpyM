﻿using System;

// Token: 0x02002870 RID: 10352
public class GClass10349
{
	// Token: 0x060050DE RID: 20702 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
