﻿using System;

// Token: 0x02002779 RID: 10105
public class GClass10102
{
	// Token: 0x06004EF0 RID: 20208 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
