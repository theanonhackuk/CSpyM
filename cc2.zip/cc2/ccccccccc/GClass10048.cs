﻿using System;

// Token: 0x02002743 RID: 10051
public class GClass10048
{
	// Token: 0x06004E84 RID: 20100 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
