﻿using System;

// Token: 0x0200281B RID: 10267
public class GClass10264
{
	// Token: 0x06005034 RID: 20532 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
