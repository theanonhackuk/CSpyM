﻿using System;

// Token: 0x020027BD RID: 10173
public class GClass10170
{
	// Token: 0x06004F78 RID: 20344 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
