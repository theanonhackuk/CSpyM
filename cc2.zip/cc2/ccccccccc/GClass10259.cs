﻿using System;

// Token: 0x02002816 RID: 10262
public class GClass10259
{
	// Token: 0x0600502A RID: 20522 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
