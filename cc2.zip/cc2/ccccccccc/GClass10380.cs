﻿using System;

// Token: 0x0200288F RID: 10383
public class GClass10380
{
	// Token: 0x0600511C RID: 20764 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
