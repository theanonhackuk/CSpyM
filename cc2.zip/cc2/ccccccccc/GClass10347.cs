﻿using System;

// Token: 0x0200286E RID: 10350
public class GClass10347
{
	// Token: 0x060050DA RID: 20698 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
