﻿using System;

// Token: 0x0200282C RID: 10284
public class GClass10281
{
	// Token: 0x06005056 RID: 20566 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
