﻿using System;

// Token: 0x020028AF RID: 10415
public class GClass10412
{
	// Token: 0x0600515C RID: 20828 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
