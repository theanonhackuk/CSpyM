﻿using System;

// Token: 0x02002852 RID: 10322
public class GClass10319
{
	// Token: 0x060050A2 RID: 20642 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
