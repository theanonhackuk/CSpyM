﻿using System;

// Token: 0x02002738 RID: 10040
public class GClass10037
{
	// Token: 0x06004E6E RID: 20078 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
