﻿using System;

// Token: 0x0200284C RID: 10316
public class GClass10313
{
	// Token: 0x06005096 RID: 20630 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
