﻿using System;

// Token: 0x020027FF RID: 10239
public class GClass10236
{
	// Token: 0x06004FFC RID: 20476 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
