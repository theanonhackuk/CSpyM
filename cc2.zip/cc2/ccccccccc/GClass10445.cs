﻿using System;

// Token: 0x020028D0 RID: 10448
public class GClass10445
{
	// Token: 0x0600519E RID: 20894 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
