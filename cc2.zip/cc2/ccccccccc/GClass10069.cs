﻿using System;

// Token: 0x02002758 RID: 10072
public class GClass10069
{
	// Token: 0x06004EAE RID: 20142 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
