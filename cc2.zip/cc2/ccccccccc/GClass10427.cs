﻿using System;

// Token: 0x020028BE RID: 10430
public class GClass10427
{
	// Token: 0x0600517A RID: 20858 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
