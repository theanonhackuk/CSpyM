﻿using System;

// Token: 0x02002867 RID: 10343
public class GClass10340
{
	// Token: 0x060050CC RID: 20684 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
