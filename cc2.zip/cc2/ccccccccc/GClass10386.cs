﻿using System;

// Token: 0x02002895 RID: 10389
public class GClass10386
{
	// Token: 0x06005128 RID: 20776 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
