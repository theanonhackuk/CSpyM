﻿using System;

// Token: 0x0200282D RID: 10285
public class GClass10282
{
	// Token: 0x06005058 RID: 20568 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
