﻿using System;

// Token: 0x020027A8 RID: 10152
public class GClass10149
{
	// Token: 0x06004F4E RID: 20302 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
