﻿using System;

// Token: 0x020028C6 RID: 10438
public class GClass10435
{
	// Token: 0x0600518A RID: 20874 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
