﻿using System;

// Token: 0x020028A3 RID: 10403
public class GClass10400
{
	// Token: 0x06005144 RID: 20804 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
