﻿using System;

// Token: 0x02002897 RID: 10391
public class GClass10388
{
	// Token: 0x0600512C RID: 20780 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
