﻿using System;

// Token: 0x020027E3 RID: 10211
public class GClass10208
{
	// Token: 0x06004FC4 RID: 20420 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
