﻿using System;

// Token: 0x020028A8 RID: 10408
public class GClass10405
{
	// Token: 0x0600514E RID: 20814 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
