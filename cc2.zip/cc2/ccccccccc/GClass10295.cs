﻿using System;

// Token: 0x0200283A RID: 10298
public class GClass10295
{
	// Token: 0x06005072 RID: 20594 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
