﻿using System;

// Token: 0x020028BA RID: 10426
public class GClass10423
{
	// Token: 0x06005172 RID: 20850 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
