﻿using System;

// Token: 0x020027C6 RID: 10182
public class GClass10179
{
	// Token: 0x06004F8A RID: 20362 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
