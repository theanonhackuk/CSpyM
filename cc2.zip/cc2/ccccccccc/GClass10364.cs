﻿using System;

// Token: 0x0200287F RID: 10367
public class GClass10364
{
	// Token: 0x060050FC RID: 20732 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
