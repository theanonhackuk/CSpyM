﻿using System;

// Token: 0x02002889 RID: 10377
public class GClass10374
{
	// Token: 0x06005110 RID: 20752 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
