﻿using System;

// Token: 0x02002831 RID: 10289
public class GClass10286
{
	// Token: 0x06005060 RID: 20576 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
