﻿using System;

// Token: 0x020003EF RID: 1007
public class GClass1004
{
	// Token: 0x060007DC RID: 2012 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
