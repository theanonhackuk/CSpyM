﻿using System;

// Token: 0x020003FA RID: 1018
public class GClass1015
{
	// Token: 0x060007F2 RID: 2034 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
