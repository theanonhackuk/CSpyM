﻿using System;

// Token: 0x02002820 RID: 10272
public class GClass10269
{
	// Token: 0x0600503E RID: 20542 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
