﻿using System;

// Token: 0x020028CF RID: 10447
public class GClass10444
{
	// Token: 0x0600519C RID: 20892 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
