﻿using System;

// Token: 0x0200282E RID: 10286
public class GClass10283
{
	// Token: 0x0600505A RID: 20570 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
