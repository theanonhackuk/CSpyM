﻿using System;

// Token: 0x0200278B RID: 10123
public class GClass10120
{
	// Token: 0x06004F14 RID: 20244 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
