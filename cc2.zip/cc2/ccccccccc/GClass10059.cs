﻿using System;

// Token: 0x0200274E RID: 10062
public class GClass10059
{
	// Token: 0x06004E9A RID: 20122 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
