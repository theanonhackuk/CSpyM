﻿using System;

// Token: 0x02000416 RID: 1046
public class GClass1043
{
	// Token: 0x0600082A RID: 2090 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
