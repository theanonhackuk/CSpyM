﻿using System;

// Token: 0x0200276C RID: 10092
public class GClass10089
{
	// Token: 0x06004ED6 RID: 20182 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
