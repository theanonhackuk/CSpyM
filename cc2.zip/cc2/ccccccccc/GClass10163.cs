﻿using System;

// Token: 0x020027B6 RID: 10166
public class GClass10163
{
	// Token: 0x06004F6A RID: 20330 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
