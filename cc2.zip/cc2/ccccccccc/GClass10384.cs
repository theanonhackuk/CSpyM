﻿using System;

// Token: 0x02002893 RID: 10387
public class GClass10384
{
	// Token: 0x06005124 RID: 20772 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
