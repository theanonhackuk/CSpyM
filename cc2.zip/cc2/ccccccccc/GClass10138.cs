﻿using System;

// Token: 0x0200279D RID: 10141
public class GClass10138
{
	// Token: 0x06004F38 RID: 20280 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
