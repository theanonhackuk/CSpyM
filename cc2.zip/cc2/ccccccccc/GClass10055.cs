﻿using System;

// Token: 0x0200274A RID: 10058
public class GClass10055
{
	// Token: 0x06004E92 RID: 20114 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
