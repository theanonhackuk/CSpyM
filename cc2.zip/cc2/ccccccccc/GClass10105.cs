﻿using System;

// Token: 0x0200277C RID: 10108
public class GClass10105
{
	// Token: 0x06004EF6 RID: 20214 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
