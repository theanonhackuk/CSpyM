﻿using System;

// Token: 0x020027D3 RID: 10195
public class GClass10192
{
	// Token: 0x06004FA4 RID: 20388 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
