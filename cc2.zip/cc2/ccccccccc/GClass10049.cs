﻿using System;

// Token: 0x02002744 RID: 10052
public class GClass10049
{
	// Token: 0x06004E86 RID: 20102 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
