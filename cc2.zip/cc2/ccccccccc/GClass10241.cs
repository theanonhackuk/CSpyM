﻿using System;

// Token: 0x02002804 RID: 10244
public class GClass10241
{
	// Token: 0x06005006 RID: 20486 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
