﻿using System;

// Token: 0x02002774 RID: 10100
public class GClass10097
{
	// Token: 0x06004EE6 RID: 20198 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
