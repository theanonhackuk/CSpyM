﻿using System;

// Token: 0x020003F3 RID: 1011
public class GClass1008
{
	// Token: 0x060007E4 RID: 2020 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
