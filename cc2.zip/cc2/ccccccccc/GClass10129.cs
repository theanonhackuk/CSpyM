﻿using System;

// Token: 0x02002794 RID: 10132
public class GClass10129
{
	// Token: 0x06004F26 RID: 20262 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
