﻿using System;

// Token: 0x02002781 RID: 10113
public class GClass10110
{
	// Token: 0x06004F00 RID: 20224 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
