﻿using System;

// Token: 0x02002821 RID: 10273
public class GClass10270
{
	// Token: 0x06005040 RID: 20544 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
