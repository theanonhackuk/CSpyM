﻿using System;

// Token: 0x020027D6 RID: 10198
public class GClass10195
{
	// Token: 0x06004FAA RID: 20394 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
