﻿using System;

// Token: 0x02002899 RID: 10393
public class GClass10390
{
	// Token: 0x06005130 RID: 20784 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
