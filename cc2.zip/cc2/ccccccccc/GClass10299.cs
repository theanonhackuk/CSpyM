﻿using System;

// Token: 0x0200283E RID: 10302
public class GClass10299
{
	// Token: 0x0600507A RID: 20602 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
