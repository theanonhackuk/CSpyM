﻿using System;

// Token: 0x0200281F RID: 10271
public class GClass10268
{
	// Token: 0x0600503C RID: 20540 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
