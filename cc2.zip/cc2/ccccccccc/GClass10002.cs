﻿using System;

// Token: 0x02002715 RID: 10005
public class GClass10002
{
	// Token: 0x06004E28 RID: 20008 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
