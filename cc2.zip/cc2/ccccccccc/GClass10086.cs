﻿using System;

// Token: 0x02002769 RID: 10089
public class GClass10086
{
	// Token: 0x06004ED0 RID: 20176 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
