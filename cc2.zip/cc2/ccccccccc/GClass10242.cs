﻿using System;

// Token: 0x02002805 RID: 10245
public class GClass10242
{
	// Token: 0x06005008 RID: 20488 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
