﻿using System;

// Token: 0x0200288E RID: 10382
public class GClass10379
{
	// Token: 0x0600511A RID: 20762 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
