﻿using System;

// Token: 0x02002825 RID: 10277
public class GClass10274
{
	// Token: 0x06005048 RID: 20552 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
