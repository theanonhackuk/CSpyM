﻿using System;

// Token: 0x02002760 RID: 10080
public class GClass10077
{
	// Token: 0x06004EBE RID: 20158 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
