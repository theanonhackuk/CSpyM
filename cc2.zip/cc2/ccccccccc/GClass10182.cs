﻿using System;

// Token: 0x020027C9 RID: 10185
public class GClass10182
{
	// Token: 0x06004F90 RID: 20368 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
