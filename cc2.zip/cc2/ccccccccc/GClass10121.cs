﻿using System;

// Token: 0x0200278C RID: 10124
public class GClass10121
{
	// Token: 0x06004F16 RID: 20246 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
