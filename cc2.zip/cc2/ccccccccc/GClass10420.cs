﻿using System;

// Token: 0x020028B7 RID: 10423
public class GClass10420
{
	// Token: 0x0600516C RID: 20844 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
