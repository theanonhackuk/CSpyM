﻿using System;

// Token: 0x0200286B RID: 10347
public class GClass10344
{
	// Token: 0x060050D4 RID: 20692 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
