﻿using System;

// Token: 0x02002784 RID: 10116
public class GClass10113
{
	// Token: 0x06004F06 RID: 20230 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
