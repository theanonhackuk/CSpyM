﻿using System;

// Token: 0x02002772 RID: 10098
public class GClass10095
{
	// Token: 0x06004EE2 RID: 20194 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
