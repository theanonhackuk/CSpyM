﻿using System;

// Token: 0x0200282B RID: 10283
public class GClass10280
{
	// Token: 0x06005054 RID: 20564 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
