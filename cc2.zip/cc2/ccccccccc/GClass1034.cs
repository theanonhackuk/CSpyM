﻿using System;

// Token: 0x0200040D RID: 1037
public class GClass1034
{
	// Token: 0x06000818 RID: 2072 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
