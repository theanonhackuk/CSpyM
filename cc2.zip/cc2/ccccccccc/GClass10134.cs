﻿using System;

// Token: 0x02002799 RID: 10137
public class GClass10134
{
	// Token: 0x06004F30 RID: 20272 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
