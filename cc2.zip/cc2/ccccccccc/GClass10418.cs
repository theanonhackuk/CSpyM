﻿using System;

// Token: 0x020028B5 RID: 10421
public class GClass10418
{
	// Token: 0x06005168 RID: 20840 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
