﻿using System;

// Token: 0x02002791 RID: 10129
public class GClass10126
{
	// Token: 0x06004F20 RID: 20256 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
