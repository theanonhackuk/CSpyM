﻿using System;

// Token: 0x020027D1 RID: 10193
public class GClass10190
{
	// Token: 0x06004FA0 RID: 20384 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
