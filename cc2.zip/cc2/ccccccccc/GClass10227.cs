﻿using System;

// Token: 0x020027F6 RID: 10230
public class GClass10227
{
	// Token: 0x06004FEA RID: 20458 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
