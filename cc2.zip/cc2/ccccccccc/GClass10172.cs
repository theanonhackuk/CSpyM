﻿using System;

// Token: 0x020027BF RID: 10175
public class GClass10172
{
	// Token: 0x06004F7C RID: 20348 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
