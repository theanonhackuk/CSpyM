﻿using System;

// Token: 0x020027AE RID: 10158
public class GClass10155
{
	// Token: 0x06004F5A RID: 20314 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
