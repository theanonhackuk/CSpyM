﻿using System;

// Token: 0x02002745 RID: 10053
public class GClass10050
{
	// Token: 0x06004E88 RID: 20104 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
