﻿using System;

// Token: 0x0200271C RID: 10012
public class GClass10009
{
	// Token: 0x06004E36 RID: 20022 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
