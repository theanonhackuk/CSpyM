﻿using System;

// Token: 0x020003EC RID: 1004
public class GClass1001
{
	// Token: 0x060007D6 RID: 2006 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
