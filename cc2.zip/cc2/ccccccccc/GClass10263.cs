﻿using System;

// Token: 0x0200281A RID: 10266
public class GClass10263
{
	// Token: 0x06005032 RID: 20530 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
