﻿using System;

// Token: 0x020027A7 RID: 10151
public class GClass10148
{
	// Token: 0x06004F4C RID: 20300 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
