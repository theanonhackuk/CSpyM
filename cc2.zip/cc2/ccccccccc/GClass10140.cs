﻿using System;

// Token: 0x0200279F RID: 10143
public class GClass10140
{
	// Token: 0x06004F3C RID: 20284 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
