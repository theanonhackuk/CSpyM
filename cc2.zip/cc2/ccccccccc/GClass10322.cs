﻿using System;

// Token: 0x02002855 RID: 10325
public class GClass10322
{
	// Token: 0x060050A8 RID: 20648 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
