﻿using System;

// Token: 0x020028B9 RID: 10425
public class GClass10422
{
	// Token: 0x06005170 RID: 20848 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
