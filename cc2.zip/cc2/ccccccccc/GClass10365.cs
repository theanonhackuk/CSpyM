﻿using System;

// Token: 0x02002880 RID: 10368
public class GClass10365
{
	// Token: 0x060050FE RID: 20734 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
