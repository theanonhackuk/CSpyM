﻿using System;

// Token: 0x02002780 RID: 10112
public class GClass10109
{
	// Token: 0x06004EFE RID: 20222 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
