﻿using System;

// Token: 0x020028B2 RID: 10418
public class GClass10415
{
	// Token: 0x06005162 RID: 20834 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
