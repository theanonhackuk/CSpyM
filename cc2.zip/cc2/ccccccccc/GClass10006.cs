﻿using System;

// Token: 0x02002719 RID: 10009
public class GClass10006
{
	// Token: 0x06004E30 RID: 20016 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
