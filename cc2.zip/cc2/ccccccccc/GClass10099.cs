﻿using System;

// Token: 0x02002776 RID: 10102
public class GClass10099
{
	// Token: 0x06004EEA RID: 20202 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
