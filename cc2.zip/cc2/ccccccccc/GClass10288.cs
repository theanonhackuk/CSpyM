﻿using System;

// Token: 0x02002833 RID: 10291
public class GClass10288
{
	// Token: 0x06005064 RID: 20580 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
