﻿using System;

// Token: 0x02002861 RID: 10337
public class GClass10334
{
	// Token: 0x060050C0 RID: 20672 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
