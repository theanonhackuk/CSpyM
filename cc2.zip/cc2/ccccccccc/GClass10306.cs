﻿using System;

// Token: 0x02002845 RID: 10309
public class GClass10306
{
	// Token: 0x06005088 RID: 20616 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
