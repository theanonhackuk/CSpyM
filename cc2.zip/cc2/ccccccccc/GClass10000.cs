﻿using System;

// Token: 0x02002713 RID: 10003
public class GClass10000
{
	// Token: 0x06004E24 RID: 20004 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
