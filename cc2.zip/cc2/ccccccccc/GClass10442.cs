﻿using System;

// Token: 0x020028CD RID: 10445
public class GClass10442
{
	// Token: 0x06005198 RID: 20888 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
