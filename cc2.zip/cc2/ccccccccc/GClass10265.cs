﻿using System;

// Token: 0x0200281C RID: 10268
public class GClass10265
{
	// Token: 0x06005036 RID: 20534 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
