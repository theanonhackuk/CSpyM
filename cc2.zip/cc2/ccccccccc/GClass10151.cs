﻿using System;

// Token: 0x020027AA RID: 10154
public class GClass10151
{
	// Token: 0x06004F52 RID: 20306 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
