﻿using System;

// Token: 0x020003FC RID: 1020
public class GClass1017
{
	// Token: 0x060007F6 RID: 2038 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
