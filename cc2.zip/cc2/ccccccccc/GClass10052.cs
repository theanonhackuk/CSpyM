﻿using System;

// Token: 0x02002747 RID: 10055
public class GClass10052
{
	// Token: 0x06004E8C RID: 20108 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
