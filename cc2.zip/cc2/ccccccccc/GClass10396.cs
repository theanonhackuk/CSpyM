﻿using System;

// Token: 0x0200289F RID: 10399
public class GClass10396
{
	// Token: 0x0600513C RID: 20796 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
