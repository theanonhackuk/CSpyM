﻿using System;

// Token: 0x0200282A RID: 10282
public class GClass10279
{
	// Token: 0x06005052 RID: 20562 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
