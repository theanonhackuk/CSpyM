﻿using System;

// Token: 0x0200271F RID: 10015
public class GClass10012
{
	// Token: 0x06004E3C RID: 20028 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
