﻿using System;

// Token: 0x02002829 RID: 10281
public class GClass10278
{
	// Token: 0x06005050 RID: 20560 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
