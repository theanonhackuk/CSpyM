﻿using System;

// Token: 0x02002832 RID: 10290
public class GClass10287
{
	// Token: 0x06005062 RID: 20578 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
