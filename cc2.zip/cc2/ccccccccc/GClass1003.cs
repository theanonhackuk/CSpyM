﻿using System;

// Token: 0x020003EE RID: 1006
public class GClass1003
{
	// Token: 0x060007DA RID: 2010 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
