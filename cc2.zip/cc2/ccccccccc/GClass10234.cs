﻿using System;

// Token: 0x020027FD RID: 10237
public class GClass10234
{
	// Token: 0x06004FF8 RID: 20472 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
