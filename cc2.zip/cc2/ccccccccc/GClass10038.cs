﻿using System;

// Token: 0x02002739 RID: 10041
public class GClass10038
{
	// Token: 0x06004E70 RID: 20080 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
