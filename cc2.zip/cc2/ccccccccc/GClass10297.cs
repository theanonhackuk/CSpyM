﻿using System;

// Token: 0x0200283C RID: 10300
public class GClass10297
{
	// Token: 0x06005076 RID: 20598 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
