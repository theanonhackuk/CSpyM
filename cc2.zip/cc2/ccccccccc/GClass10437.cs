﻿using System;

// Token: 0x020028C8 RID: 10440
public class GClass10437
{
	// Token: 0x0600518E RID: 20878 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
