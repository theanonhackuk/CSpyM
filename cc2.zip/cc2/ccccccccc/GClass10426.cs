﻿using System;

// Token: 0x020028BD RID: 10429
public class GClass10426
{
	// Token: 0x06005178 RID: 20856 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
