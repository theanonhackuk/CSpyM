﻿using System;

// Token: 0x02002887 RID: 10375
public class GClass10372
{
	// Token: 0x0600510C RID: 20748 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
