﻿using System;

// Token: 0x020028BC RID: 10428
public class GClass10425
{
	// Token: 0x06005176 RID: 20854 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
