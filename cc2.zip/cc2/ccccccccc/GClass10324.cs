﻿using System;

// Token: 0x02002857 RID: 10327
public class GClass10324
{
	// Token: 0x060050AC RID: 20652 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
