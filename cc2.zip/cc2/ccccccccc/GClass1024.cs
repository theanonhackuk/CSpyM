﻿using System;

// Token: 0x02000403 RID: 1027
public class GClass1024
{
	// Token: 0x06000804 RID: 2052 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
