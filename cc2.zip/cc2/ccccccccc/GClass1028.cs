﻿using System;

// Token: 0x02000407 RID: 1031
public class GClass1028
{
	// Token: 0x0600080C RID: 2060 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
