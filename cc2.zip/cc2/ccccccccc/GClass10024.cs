﻿using System;

// Token: 0x0200272B RID: 10027
public class GClass10024
{
	// Token: 0x06004E54 RID: 20052 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
