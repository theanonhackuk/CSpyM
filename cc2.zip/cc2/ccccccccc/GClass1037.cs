﻿using System;

// Token: 0x02000410 RID: 1040
public class GClass1037
{
	// Token: 0x0600081E RID: 2078 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
