﻿using System;

// Token: 0x020027A4 RID: 10148
public class GClass10145
{
	// Token: 0x06004F46 RID: 20294 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
