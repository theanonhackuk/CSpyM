﻿using System;

// Token: 0x020027F7 RID: 10231
public class GClass10228
{
	// Token: 0x06004FEC RID: 20460 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
