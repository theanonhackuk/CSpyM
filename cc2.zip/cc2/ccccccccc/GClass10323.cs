﻿using System;

// Token: 0x02002856 RID: 10326
public class GClass10323
{
	// Token: 0x060050AA RID: 20650 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
