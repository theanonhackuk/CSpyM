﻿using System;

// Token: 0x020027ED RID: 10221
public class GClass10218
{
	// Token: 0x06004FD8 RID: 20440 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
