﻿using System;

// Token: 0x020027B8 RID: 10168
public class GClass10165
{
	// Token: 0x06004F6E RID: 20334 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
