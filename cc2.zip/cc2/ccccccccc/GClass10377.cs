﻿using System;

// Token: 0x0200288C RID: 10380
public class GClass10377
{
	// Token: 0x06005116 RID: 20758 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
