﻿using System;

// Token: 0x020027E0 RID: 10208
public class GClass10205
{
	// Token: 0x06004FBE RID: 20414 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
