﻿using System;

// Token: 0x0200278F RID: 10127
public class GClass10124
{
	// Token: 0x06004F1C RID: 20252 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
