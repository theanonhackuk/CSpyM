﻿using System;

// Token: 0x0200040C RID: 1036
public class GClass1033
{
	// Token: 0x06000816 RID: 2070 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
