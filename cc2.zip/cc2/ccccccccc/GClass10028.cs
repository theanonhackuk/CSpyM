﻿using System;

// Token: 0x0200272F RID: 10031
public class GClass10028
{
	// Token: 0x06004E5C RID: 20060 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
