﻿using System;

// Token: 0x0200276D RID: 10093
public class GClass10090
{
	// Token: 0x06004ED8 RID: 20184 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
