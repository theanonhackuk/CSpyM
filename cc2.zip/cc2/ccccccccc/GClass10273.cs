﻿using System;

// Token: 0x02002824 RID: 10276
public class GClass10273
{
	// Token: 0x06005046 RID: 20550 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
