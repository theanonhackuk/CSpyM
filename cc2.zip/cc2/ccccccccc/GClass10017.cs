﻿using System;

// Token: 0x02002724 RID: 10020
public class GClass10017
{
	// Token: 0x06004E46 RID: 20038 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
