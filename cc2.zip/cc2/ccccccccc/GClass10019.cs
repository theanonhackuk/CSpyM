﻿using System;

// Token: 0x02002726 RID: 10022
public class GClass10019
{
	// Token: 0x06004E4A RID: 20042 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
