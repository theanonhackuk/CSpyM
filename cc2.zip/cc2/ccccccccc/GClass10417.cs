﻿using System;

// Token: 0x020028B4 RID: 10420
public class GClass10417
{
	// Token: 0x06005166 RID: 20838 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
