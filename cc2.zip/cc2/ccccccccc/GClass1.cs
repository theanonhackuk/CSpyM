﻿using System;

// Token: 0x02000004 RID: 4
public class GClass1
{
	// Token: 0x06000006 RID: 6 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
