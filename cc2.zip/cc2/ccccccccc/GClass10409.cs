﻿using System;

// Token: 0x020028AC RID: 10412
public class GClass10409
{
	// Token: 0x06005156 RID: 20822 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
