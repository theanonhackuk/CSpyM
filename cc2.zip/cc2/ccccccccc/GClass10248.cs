﻿using System;

// Token: 0x0200280B RID: 10251
public class GClass10248
{
	// Token: 0x06005014 RID: 20500 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
