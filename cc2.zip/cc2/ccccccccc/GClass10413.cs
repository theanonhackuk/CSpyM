﻿using System;

// Token: 0x020028B0 RID: 10416
public class GClass10413
{
	// Token: 0x0600515E RID: 20830 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
