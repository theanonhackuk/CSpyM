﻿using System;

// Token: 0x02002717 RID: 10007
public class GClass10004
{
	// Token: 0x06004E2C RID: 20012 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
