﻿using System;

// Token: 0x02002753 RID: 10067
public class GClass10064
{
	// Token: 0x06004EA4 RID: 20132 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
