﻿using System;

// Token: 0x02002714 RID: 10004
public class GClass10001
{
	// Token: 0x06004E26 RID: 20006 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
