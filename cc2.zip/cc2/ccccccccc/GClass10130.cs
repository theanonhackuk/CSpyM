﻿using System;

// Token: 0x02002795 RID: 10133
public class GClass10130
{
	// Token: 0x06004F28 RID: 20264 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
