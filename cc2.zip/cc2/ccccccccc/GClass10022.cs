﻿using System;

// Token: 0x02002729 RID: 10025
public class GClass10022
{
	// Token: 0x06004E50 RID: 20048 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
