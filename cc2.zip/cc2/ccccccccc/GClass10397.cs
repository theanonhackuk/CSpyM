﻿using System;

// Token: 0x020028A0 RID: 10400
public class GClass10397
{
	// Token: 0x0600513E RID: 20798 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
