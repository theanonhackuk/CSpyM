﻿using System;

// Token: 0x0200276F RID: 10095
public class GClass10092
{
	// Token: 0x06004EDC RID: 20188 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
