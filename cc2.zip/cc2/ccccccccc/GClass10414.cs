﻿using System;

// Token: 0x020028B1 RID: 10417
public class GClass10414
{
	// Token: 0x06005160 RID: 20832 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
