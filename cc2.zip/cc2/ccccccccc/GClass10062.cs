﻿using System;

// Token: 0x02002751 RID: 10065
public class GClass10062
{
	// Token: 0x06004EA0 RID: 20128 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
