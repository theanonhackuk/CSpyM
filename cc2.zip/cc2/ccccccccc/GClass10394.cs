﻿using System;

// Token: 0x0200289D RID: 10397
public class GClass10394
{
	// Token: 0x06005138 RID: 20792 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
