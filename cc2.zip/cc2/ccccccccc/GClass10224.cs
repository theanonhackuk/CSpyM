﻿using System;

// Token: 0x020027F3 RID: 10227
public class GClass10224
{
	// Token: 0x06004FE4 RID: 20452 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
