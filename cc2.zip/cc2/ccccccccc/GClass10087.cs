﻿using System;

// Token: 0x0200276A RID: 10090
public class GClass10087
{
	// Token: 0x06004ED2 RID: 20178 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
