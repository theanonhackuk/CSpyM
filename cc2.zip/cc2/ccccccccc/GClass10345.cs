﻿using System;

// Token: 0x0200286C RID: 10348
public class GClass10345
{
	// Token: 0x060050D6 RID: 20694 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
