﻿using System;

// Token: 0x0200271D RID: 10013
public class GClass10010
{
	// Token: 0x06004E38 RID: 20024 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
