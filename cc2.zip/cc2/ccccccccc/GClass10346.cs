﻿using System;

// Token: 0x0200286D RID: 10349
public class GClass10346
{
	// Token: 0x060050D8 RID: 20696 RVA: 0x00002134 File Offset: 0x00000334
	private void method_0()
	{
	}
}
