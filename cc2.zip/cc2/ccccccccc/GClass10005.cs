﻿using System;

// Token: 0x02002718 RID: 10008
public class GClass10005
{
	// Token: 0x06004E2E RID: 20014 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
