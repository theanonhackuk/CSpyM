﻿using System;

// Token: 0x02002896 RID: 10390
public class GClass10387
{
	// Token: 0x0600512A RID: 20778 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
