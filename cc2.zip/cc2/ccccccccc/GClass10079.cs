﻿using System;

// Token: 0x02002762 RID: 10082
public class GClass10079
{
	// Token: 0x06004EC2 RID: 20162 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
