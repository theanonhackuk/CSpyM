﻿using System;

// Token: 0x02002733 RID: 10035
public class GClass10032
{
	// Token: 0x06004E64 RID: 20068 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
