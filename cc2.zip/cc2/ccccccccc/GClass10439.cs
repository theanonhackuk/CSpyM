﻿using System;

// Token: 0x020028CA RID: 10442
public class GClass10439
{
	// Token: 0x06005192 RID: 20882 RVA: 0x00002154 File Offset: 0x00000354
	private void method_0()
	{
	}
}
