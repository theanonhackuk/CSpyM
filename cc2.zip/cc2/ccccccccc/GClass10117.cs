﻿using System;

// Token: 0x02002788 RID: 10120
public class GClass10117
{
	// Token: 0x06004F0E RID: 20238 RVA: 0x00002144 File Offset: 0x00000344
	private void method_0()
	{
	}
}
