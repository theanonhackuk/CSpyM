﻿using System;

// Token: 0x0200040E RID: 1038
public class GClass1035
{
	// Token: 0x0600081A RID: 2074 RVA: 0x00002124 File Offset: 0x00000324
	private void method_0()
	{
	}
}
